function startMove( ele, attr, iTarget, fn ) {
	clearInterval(ele.timer);
	ele.timer = setInterval(function() {
		//取得当前的值
		var icur = 0;
		if ( attr == "opacity" ) {
			icur = Math.round(parseFloat(getStyle(ele, attr))*100);
		} else {
			icur = parseInt(getStyle(ele, attr));
		}
		var speed = ( iTarget - icur ) / 8;
		speed = speed > 0 ? Math.ceil(speed) : Math.floor(speed);

		if ( icur == iTarget ) {
			clearInterval(ele.timer);
			if( fn ) {
				fn();
			}
		} else {
			if ( attr == 'opacity' ) {
				ele.style.filter = 'alpha(opacity:'+ (icur+speed) +')';
				ele.style.opacity = (icur+speed) /100;
			} else {
				ele.style[attr] = icur +speed + "px";
			}
		}
	},30);
}

function getStyle(obj,attr) {
	if( obj.currentStyle ) {
		return obj.currentStyle[attr];
	} else {
		return window.getComputedStyle(obj,false)[attr];
	}
}