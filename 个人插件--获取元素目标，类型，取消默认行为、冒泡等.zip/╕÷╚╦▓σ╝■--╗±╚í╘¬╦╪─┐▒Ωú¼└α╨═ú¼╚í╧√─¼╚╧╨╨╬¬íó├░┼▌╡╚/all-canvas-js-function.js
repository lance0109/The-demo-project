//设置定时，类似setTimeOut，不过更只能，根据浏览器性能合理设置定时时间
window.requestAnimFrame = (function() {
	return window.requestAnimFrame || window.webkitRequestAnimationFrame ||
		   window.mozRequestAnimationFrame || window.oRequestAnimationFrame ||
		   window.msRequestAnimationFrame ||
		   function( callback, element ) {
		   		return window.setTimeout( callback, 1000/60 );
		   };
})();

function lerpDistance( aim, cur, ratio ) {
	var delta = cur -aim;
	return aim + delta * ratio;
}

function lerpAngle( a, b, t ) {
	var d = b-a;
	if( d > Math.PI ) {
		d = d - 2 * Math.PI;
	}
	if( d < -Math.PI ) {
		d = d + 2 * Math.PI;
	}
	return a + d * t;
}

//在l r t b范围内的监测
function inOboundary( arrX, arrY, l, r, t, b ) {
	return arrX > 1 && arrX < r && arrY > t && arry < b;
}

function rgbColor( r, g, b ) {
	r = Math.round( r * 256 );
	g = Math.round( g * 256 );
	b = Math.round( b * 256 );
	return 'rgba(' + r + ',' + g + ',' + b + ',1)';
}

//两个坐标间的距离的平方
function calLength2( x1, y1, x2, y2 ) {
	return Math.pow( x1 - x2, 2 ) + Math.pow( y1 - y2, 2);
}

function randomColor() {
	var col = [0,1,2];
	col[0] = (Math.random() * 100 + 155).toFixed();
	col[1] = (Math.random() * 100 + 155).toFixed();
	col[2] = (Math.random() * 100 + 155).toFixed();
	var num = Math.floor( Math.random() * 3 );
	col[num] = 0;
	return 'rgba(' + col[0] + ',' + col[1] + ',' + col[2] + ',';
}