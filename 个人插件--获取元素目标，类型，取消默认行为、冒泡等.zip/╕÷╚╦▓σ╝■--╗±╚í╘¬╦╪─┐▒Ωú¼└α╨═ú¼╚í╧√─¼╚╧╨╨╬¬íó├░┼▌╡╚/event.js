var eventUtil = {
	//添加事件监听
	addListener: function(e, type, fn) {
		if ( e.addEventListener ) {
			e.addEventListener( type, fn, false );
		} else if ( e.attachEvent ) {
			e.attachEvent( 'on' + type, fn );
		} else {
			e['on' + type] = fn;
		}
	},

	//移除事件监听
	removeListener: function(e, type, fn) {
		if( e.removeEventListener ) {
			e.removeEventListener( type, fn, false);
		} else if( e.detachEvent ) {
			e.detachEvent( 'on'+type, fn );
		} else {
			e['on' + type] = null;
		}
	},

	//获取event类型
	getType: function(e) {
		return e.type;
	},

	//获取event
	getEvent: function(e) {
		return e || window.event;
	},

	//获取event目标
	getEventTarget: function(e) {
		return e.target || e.srcElement;
	},

	//阻止event默认行为
	stopDefault: function(e) {
		if( e.preventDefault ) {
			e.preventDefault();
		} else {
			e.returnValue = false;
		}
	},

	//阻止冒泡
	stopBubble: function(e) {
		if( e.stopPropagation ) {
			e.stopPropagation();
		} else {
			e.cancelBubble = true;
		}
	}
};

//事件代理
var delegateEvent = function( target, event, fn ) {
	addListener(document, event, function(e) {
		if( e.target.nodeName == target.toUppercase() ) {
			fn.call(e.target);
		}
	});
};