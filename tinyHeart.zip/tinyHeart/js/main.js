var can1,
	can2,
	ctx1,
	ctx2,
	canW,
	canH,
	lastTime,
	deltaTime,
	ane,
	fruit,
	mom,
	baby,
	data,
	wave,
	halo,
	dust,
	mx,
	my;

var babyTail = [];
var babyEye = [];
var babyBody = [];

var momTail = [];
var momEye = [];
var momBodyOra = [];
var momBodyBlue = [];

var dustPic = [];

var bgPic = new Image();

document.body.onload = game;

function game() {
	init();
	lastTime = Date.now();
	deltaTime = 0;
	gameLoop();
}

function init() {
	can1 = document.getElementById('canvas1');
	ctx1 = can1.getContext('2d');
	can2 = document.getElementById('canvas2');
	ctx2 = can2.getContext('2d');

	can1.addEventListener('mousemove', onMouseMove, false);

	canW = can1.width;
	canH = can1.height;

	mx = canW/2;
	my = canH/2;

	bgPic.src = 'img/background.jpg';

	ane = new aneObj();
	ane.init();	

	fruit = new fruitObj();
	fruit.init();

	mom = new momObj();
	mom.init();

	baby = new babyObj();
	baby.init();

	data = new dataObj();

	wave = new waveObj();
	wave.init();

	halo = new haloObj();
	halo.init();

	dust = new dustObj();
	dust.init();

	for( var i=0; i<8; i++ ) {
		babyTail[i] = new Image();
		babyTail[i].src = 'img/babyTail' + i + '.png';
	}

	for( var i=0; i<2; i++ ) {
		babyEye[i] = new Image();
		babyEye[i].src = 'img/babyEye' + i + '.png';
	}

	for( var i=0; i<20; i++ ) {
		babyBody[i] = new Image();
		babyBody[i].src = 'img/babyFade' + i + '.png';
	}

	for( var i=0; i<8; i++ ) {
		momTail[i] = new Image();
		momTail[i].src = 'img/bigTail' + i + '.png';
	}

	for( var i=0; i<2; i++ ) {
		momEye[i] = new Image();
		momEye[i].src = 'img/bigEye' + i + '.png';
	}

	for( var i=0; i<8; i++ ) {
		momBodyOra[i] = new Image();
		momBodyOra[i].src = 'img/bigSwim' + i + '.png';

		momBodyBlue[i] = new Image();
		momBodyBlue[i].src = 'img/bigSwimBlue' + i + '.png';
	}

	for( var i=0; i<7; i++ ) {
		dustPic[i] = new Image();
		dustPic[i].src = 'img/dust' + i + '.png';
	}

	ctx1.font = '28px Verdana';
	ctx1.textAlign = 'center';
	ctx1.fillStyle = '#fff';

}

function gameLoop() {
	window.requestAnimFrame( gameLoop );
	var now = Date.now();
	deltaTime = now - lastTime;
	lastTime = now;
	if( deltaTime > 40 ) {
		deltaTime = 40;	
	}

	drawBg();
	ane.draw();
	fruitMonitor();
	fruit.draw();

	ctx1.clearRect( 0, 0, canW, canH );
	mom.draw();
	baby.draw();
	momFruitsCollision();
	momBabyCollision();
	
	data.draw();
	wave.draw();
	halo.draw();
	dust.draw();

}

function onMouseMove(e) {
	if( !data.gameOver ) {
		if( e.offsetX || e.layerX ) {
			mx = e.offsetX == undefined ? e.layerX : e.offsetX;
			my = e.offsetY == undefined ? e.layerY : e.offsetY;
		}
	}
}

window.requestAnimFrame = (function() {
	return window.requestAnimFrame || window.webkitRequestAnimationFrame ||
		   window.mozRequestAnimationFrame || window.oRequestAnimationFrame ||
		   window.msRequestAnimationFrame ||
		   function( callback, element ) {
				return window.setTimeout( callback, 1000/60 );
		   };
})();

function lerpDistance( aim, cur, ratio ) {
	var delta = cur -aim;
	return aim + delta * ratio;
}

function lerpAngle( a, b, t ) {
	var d = b-a;
	if( d > Math.PI ) {
		d = d - 2 * Math.PI;
	}
	if( d < -Math.PI ) {
		d = d + 2 * Math.PI;
	}
	return a + d * t;
}

function calLength2( x1, y1, x2, y2 ) {
	return Math.pow( x1 - x2, 2 ) + Math.pow( y1 - y2, 2);
}
