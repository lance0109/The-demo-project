function drawBg() {
	ctx2.drawImage( bgPic , 0 , 0 , canW , canH );
}