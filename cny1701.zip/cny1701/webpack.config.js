module.exports = {
	entry: './js/app.js',
	output: {
		path: './js',
		filename: 'app.min.js'
	}
};