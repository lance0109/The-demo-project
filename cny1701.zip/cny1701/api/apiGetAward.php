<?php
include_once( 'config.php' );
include_once ("db.php");


//上线改奖品表，调中奖机率

//抽奖速度过快
if(limitTry(3)){
	echo '{"res":-1,"msg":"你抽奖速度太快了"}';
	exit;
}

$userids = prefixSession("award_userId");
$action_time  = date("Y-m-d H:i:s",time());
$over_time 		= date("Y-m-d H:i:s",time() - 3600*8);
$sqls = "select count('id') as award from cny1701_award_log where userId=".$userids."
and ctime>='$over_time' and ctime<='$action_time'";

$res = mysql_fetch_assoc(mysql_query($sqls));


if($res['award']>=3){
	echo '{"res":-2,"msg":""}';  //你抽奖超过3次,请2小时之后再来!
	exit;
}



$arrBoss = array(
	'oV1qYwFhY8zDYZ7KFOp0zpcAk4Jk',
	'oV1qYwDFK4i4YBNdET2EsUMauNt8',  //marsha 239
	'oV1qYwA7LoSSyOpwHG1e2ad3l9ig',
	'oV1qYwM9WQ89BADHLGYAFaFeZays',
	'oV1qYwDC9IAzM5hxZq8AnFtRcBr4', //oliver  185
	'oV1qYwEOlnfehNsWOqJZA6RpvB7U',
	'oV1qYwLXaloFe-z6c3aoJKYHodHA',
	'oV1qYwEmyLW0kKqvzxz8ZCybJyVg',
	'oV1qYwGwrMQMeE3pDysk-_jjX0Q4',
	'oV1qYwKeSNtAbdF6H4SxsO5uJpmQ'
);

//设置奖品信息
$prizeList = array(
	1 => array('恭喜您获得飞利浦眼部能量仪1份！飞利浦祝您疲劳走开，双眼更有神采!', '飞利浦祝您2017新年大吉疲劳走开，双眼更有神采!'),
	2 => array('恭喜您获得飞利浦电吹风1把！飞利浦祝您鸿运当头，万事顺意!', '飞利浦祝您2017新年大吉鸿运当头，万事顺意!'),
	3 => array('恭喜您获得飞利浦空气净化器1台！飞利浦祝您畅快呼吸，尽享自由!', '飞利浦祝您2017新年大吉畅快呼吸，尽享自由!'),
	4 => array('恭喜您获得飞利浦扫地机器人1台！飞利浦祝您扫走霉运，除旧迎新!', '飞利浦祝您2017新年大吉扫走霉运，除旧迎新！'),
	5 => array('恭喜您获得飞利浦空气炸锅1台！飞利浦祝您吃出健康，更有活力!', '飞利浦祝您2017新年大吉吃出健康，更有活力！'),
	6 => array('恭喜您获得飞利浦吸乳器1台！飞利浦祝您轻松喂养，让宝宝健康成长!', '飞利浦祝您2017新年大吉轻松喂养，让宝宝健康成长！'),
	7 => array('恭喜您获得飞利浦剃须刀1把！飞利浦祝您为你原力加持，充满战斗力!', '飞利浦祝您2017新年大吉为你原力加持，充满战斗力！'),
	8 => array('恭喜您获得飞利浦高速破壁料理机1台！飞利浦祝您魔速威力，见证营养奇迹!','飞利浦祝您2017新年大吉魔速威力，见证营养奇迹！'),
	9 => array('恭喜您获得飞利浦电饭煲1台！飞利浦祝您年夜有好饭，吃出健康与团圆!', '飞利浦祝您2017新年大吉年夜有好饭，吃出健康与团圆！'),
	10 => array('恭喜您获得飞利浦男士洁面仪1把！飞利浦祝您不惧挑战，净展实力!', '飞利浦祝您2017新年大吉不惧挑战，净展实力！'),
	11 => array('恭喜您获得飞利浦电动牙刷1把！飞利浦祝您亮白笑容，魅力自信!', '飞利浦祝您2017新年大吉亮白笑容，魅力自信！'),
	12 => array('恭喜您获得飞利浦复古多功能剃须刀1台！飞利浦祝您腔调在手!，全能男神就是我', '飞利浦祝您2017新年大吉腔调在手，全能男神就是我！'),
	13 => array('恭喜您获得飞利浦电熨斗1台！飞利浦祝您扫平障碍，前途无量!','飞利浦祝您2017新年大吉扫平障碍，前途无量！'),
	14 => array('恭喜你获得一千元红包大奖', '飞利浦祝你想买啥买啥!')
);

//比较是否过期
$now = time();
if($now<strtotime('2017-01-13')){
exit('{"res":-1,"msg":"活动开始日期为2017年1月14日，请过几天再来抽奖"}');
}else if($now>strtotime('2017-01-31')){
exit('{"res":-1,"msg":"活动已经过期，感谢您的参与"}');
}


//检查是否授权
//$openid = 'oV1qYwG7VmGj6ujKXt_-wnsMtv04'; //'oV1qYwG7VmGj6ujKXt_-wnsMtv04';  $_GET['openid']
$userId = prefixSession('userId');  //
$openid = prefixSession('openid');
//$userId=1;

if(empty($userId)){
	echo '{"res":-1,"msg":"你没有微信授权，请关闭页面重新进入。"}';
	exit;
}

//没连上数据库，或连接数过高
if(empty($db)){
	echo '{"res":-1,"msg":"你没有中奖，再来一次试试手气。"}';
	exit;
}

//检查是否中过
$sql = "select userId from cny2017_award where userId='$userId'";
$result = mysql_query($sql);
$num_rows = mysql_num_rows($result);
if($num_rows>0){
	echo '{"res":-2,"msg":"你已经中过奖了。"}';
	exit;
}


//抽奖次数过多
$sql = "select count(*) from cny1701_award_log where userId='$userId'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
$tryAward = $row[0];
if($tryAward>15){
	echo '{"res":-2,"msg":""}';  //你已经抽了太多次奖了
	exit;
}

//检查奖品数量
//实物数量
$sql = "select count(*) from cny1701_product_test where is_occupy=0";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
$award1Left = $row[0];

//红包数量
$sql = "select count(*) from $redData where is_occupy=0";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
$award2Left = $row[0];

//echo $award1Left.'   '.$award2Left.'<br>';

//抽完了
if($award1Left==0&&$award2Left==0){
	echo '{"res":-1,"msg":"你没有中奖，再来一次试试手气。"}';  //你慢了一步，<br/>奖品已经发完了。
	exit;
}


//开始抽奖
$rand = rand(1, 100);
//echo $rand.'<br>';
if($rand<3 && $award1Left>0){
	//实物
	$awardType=1;
	$awardData = 'cny1701_product_test';

}else{
	$awardType=2;
	$awardData = $redData;
}

//boss只中红包
if(in_array($openid, $arrBoss)){
	$awardType=2;
	$awardData = $redData;
}


$sql = "select id,award from $awardData where is_occupy=0 limit 1";

//echo $sql.'<br>';
$result = mysql_query($sql);
$row = mysql_fetch_assoc($result);
$awardId = $row['id'];
$award = $row['award'];

$sql = "update $awardData set is_occupy=1, userId=$userId where id=$awardId and is_occupy=0";
$result = mysql_query($sql);

$affected = mysql_affected_rows();
if($affected==0){
	echo '{"res":-1,"msg":"你没有中奖，再来一次试试手气。"}';
	exit;
}

$sql1 = "insert into cny1701_award_log(userId, award_type, award_id, award) values($userId, $awardType, $awardId, $award)";
$result1 = mysql_query($sql1);

prefixSession("awardType", $awardType);
prefixSession("awardId", $awardId);
prefixSession("award", $award);
prefixSession("award_userId",$userId);


if($awardType==2){
	$msg = $prizeList[14];
	$num = 14;
}else{
	$msg = $prizeList[$award];
	$num = $award;
}
//echo $awardType.'  '.$awardId.'  '.$award.'<br>';
echo '{"res":1,"num":"'.$num.'", "msg":"恭喜中奖", "msg1":"'.$msg[0].'", "msg2":"'.$msg[1].'","aaa":"'.$result.'"}';
exit;
