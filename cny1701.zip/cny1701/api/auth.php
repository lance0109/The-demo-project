<?php

$auth = prefixSession('userId');
if(empty($auth)) {
	prefixSession("referer", $_SERVER["PHP_SELF"]);
	if(!empty($_SERVER["QUERY_STRING"])){
		prefixSession("query", $_SERVER["QUERY_STRING"]);
	}

	if(isset($_GET['hmsr'])){
		prefixSession("hmsr", addslashes($_GET['hmsr']));
	}
	$uri = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".WX_APPID."&redirect_uri=".WX_REDIRECT."&response_type=code&scope=".WX_AUTH_TYPE."&state=STATE#wechat_redirect";
	header("location:".$uri);
}
?>