<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
header('P3P: CP=CAO PSA OUR');

// 调试模式开关
define( 'DEBUG_MODE', false);
define( 'DEVELOP_MODE', false);

define( 'MYSQL_MODE', 'instance');  //instance 独享 share 共享

define( 'PROJECT_NAME', 'cny1701');  //项目目录名称
define( 'DOMAIN', "http://2016conference.8060608.com/");
define( 'BASE_URL', DOMAIN.PROJECT_NAME);
define( 'BASE_FOLDER', PROJECT_NAME);

define( 'COOKIE_PATH', '/'.PROJECT_NAME.'/');
define( 'COOKIE_EXPIRE', 60*60*24*1);
define( 'DB_PREFIX', PROJECT_NAME.'_');

define( 'STORAGE_URL', 'http://uniquewx-photo.stor.sinaapp.com/');

define( "WX_APPID", 'wx1031af73ccfe96e3' );
define( "WX_APPSECRET", '77aa75e0f859bef082062aa8dd3715e9' );
define( "WX_AUTH_TYPE", 'snsapi_userinfo' );  //获取openid使用snsapi_base，获取用户信息使用snsapi_userinfo
define( "WX_TOKEN", 'conferencewx' );
define( "WX_AESKEY", 'YCptQzx784TJ4oq56TYB6kkodmjZ0AqAjriaWkaknJ8' );
define( "WX_REDIRECT", BASE_URL.'/api/callback.php' );

$redData = 'cny1701_red'; //正式上线改成 'cny1701_red'


if ( DEBUG_MODE ) {
    error_reporting(E_ALL);
    ini_set('display_errors', true);
	//$_COOKIE["userId"] = 1;
}else{
	ini_set('display_errors', false);
}

//==============       应用设置      ==============

$options = array(
		'token'=>WX_TOKEN, //填写设定的token
		'encodingaeskey'=>WX_AESKEY, //填写加密用的EncodingAESKey，如接口为明文模式可忽略
		'appid'=> WX_APPID, //填写高级调用功能的app id
		'appsecret'=>WX_APPSECRET //填写高级调用功能的密钥
	);



function prefixCookie($name,$value=''){
	if($value===''){
		if(isset($_COOKIE[DB_PREFIX.$name])){
			return $_COOKIE[DB_PREFIX.$name];
		}else{
			return null;
		}
	}else{
		if (is_null($value)) {
			setcookie(DB_PREFIX.$name, '', time() - 3600, COOKIE_PATH);
			unset($_COOKIE[DB_PREFIX.$name]); // 删除指定cookie
		}else{
			setcookie(DB_PREFIX.$name,$value, time()+COOKIE_EXPIRE,COOKIE_PATH);
		}
	}
}

function prefixSession($name, $value=''){
	if($value===''){
		if(isset($_SESSION[PROJECT_NAME][$name])){
			return $_SESSION[PROJECT_NAME][$name];
		}else{
			return null;
		}
	}else{
		if (is_null($value)) {
			unset($_SESSION[PROJECT_NAME][$name]);
		}else{
			$_SESSION[PROJECT_NAME][$name] = $value;
		}
	}
}

//限制抽奖次数，单位秒
function limitTry($interval){
	$last_time = prefixCookie('last_time');
	$now = time();
	if(!empty($last_time)){
		if($now-$last_time<$interval){
			return true;
		}
	}
	prefixCookie('last_time', $now);
	return false;
}