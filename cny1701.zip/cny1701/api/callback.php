<?php
include "config.php";
include "db.php";



$code = isset($_GET["code"]) ? $_GET["code"] : "";
if(!empty($code)) {
	$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".WX_APPID."&secret=".WX_APPSECRET."&code=".$code."&grant_type=authorization_code";
	$res = json_decode(httpGet($url));

	$access_token = $res->access_token;
	$refresh_token = $res->refresh_token;
	$openid = $res->openid;

	if(empty($openid)){
		echo '获取用户微信信息失败，请关闭页面重试';
		exit;
	}

	$api = "https://api.weixin.qq.com/sns/userinfo?access_token=".$access_token."&openid=".$openid."&lang=zh_CN";
	$userinfo = json_decode(httpGet($api));
	$result = saveToDB($openid, $userinfo);

	if($result){
		$query = prefixSession("query");
		if(empty($query)){
			$query = '';
		}

		$hmsr = prefixSession("hmsr");
		if(empty($hmsr)){
			$hmsr = 0;
		}

		$arrQuery = array();
		parse_str($query, $arrQuery);

		$referer = prefixSession("referer");
		if(empty($referer)){
			$referer = COOKIE_PATH;
		}

		header("location:".DOMAIN.$referer.'?'.http_build_query($arrQuery));
	}else{
		echo '保存用户微信信息失败，请关闭页面重试';
		exit;
	}

}else{
	echo '微信授权失败，请重试';
}



function saveToDB($openid, $user) {
	$nickname = urlencode($user->nickname);
	$sex = $user->sex;
	$headimgurl = $user->headimgurl;

	$sql = "insert into ".DB_PREFIX."users(openid,nickname,sex,headimgurl) values('$openid','$nickname','$sex','$headimgurl')  on duplicate key update nickname='$nickname',sex='$sex',headimgurl='$headimgurl'";
	$result = mysql_query($sql);

	if($result===false){
		return false;
	}else{
		$sql = "select userId from ".DB_PREFIX."users where openid='$openid'";
		$result = mysql_query($sql);
		$row = mysql_fetch_assoc($result);
		$userId = $row['userId'];

		prefixSession("userId", $userId);
		prefixSession("openid", $openid);
		return true;
	}


}
function saveToLocal($user) {
	prefixSession("openid", $user->openid);
	prefixSession("nickname", urlencode($user->nickname)) ;
	prefixSession("headimgurl", urlencode($user->headimgurl));
	prefixSession("sex", $user->sex);

//	setcookie("openid",$user->openid, time()+COOKIE_EXPIRE,COOKIE_PATH);
//	setcookie("nickname",$user->nickname, time()+COOKIE_EXPIRE,COOKIE_PATH);
//	setcookie("sex",$user->sex, time()+COOKIE_EXPIRE,COOKIE_PATH);
//	setcookie("headimgurl",urlencode($user->headimgurl), time()+COOKIE_EXPIRE,COOKIE_PATH);
}


function httpGet($url) {
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_TIMEOUT, 500);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($curl, CURLOPT_URL, $url);
	$res = curl_exec($curl);
	curl_close($curl);
	return $res;
}


?>