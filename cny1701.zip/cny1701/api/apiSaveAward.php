<?php
include_once( 'config.php' );
include_once ("db.php");

require_once("../lib/WxPay.Api.php");
require_once("../lib/WxPay.Config.php");
require_once("../lib/WxMchPayHelper.php");


$openid   = prefixSession('openid');
$userId   = prefixSession('userId');
$awardType  = prefixSession('awardType');
$awardId   = prefixSession('awardId');
$award   = prefixSession('award');


//尝试保存次数过快
if(limitTry(3)){
	echo '{"res":-1,"msg":"你保存信息次数过快"}';
	exit;
}


//比较是否过期
$now = time();
if($now<strtotime('2017-01-13')){
	exit('{"res":-1,"msg":"活动开始日期为2017年1月14日，请过几天再来抽奖"}');
}else if($now>strtotime('2017-01-31')){
	exit('{"res":-1,"msg":"活动已经过期，感谢您的参与"}');
}


//检查是否授权
if(empty($userId)){
	resetAward($awardType, $awardId);
	echo '{"res":-1,"msg":"你没有微信授权，请关闭页面重新进入。"}';
	exit;
}

//检查是否中奖
if(empty($awardType)){
	echo '{"res":-1,"msg":"你没有中奖，请先去抽奖。"}';
	exit;
}

//检查是否中过
$sql = "select userId from cny2017_award where userId='$userId'";
$result = mysql_query($sql);
$num_rows = mysql_num_rows($result);
if($num_rows>0){
	resetAward($awardType, $awardId);
	echo '{"res":-3,"msg":"你已经中过奖了。"}';
	exit;
}

//填写表格次数过多
$sql = "select count(*) from cny2017_save_log where userId='$userId'";
$result = mysql_query($sql);
$row = mysql_fetch_array($result);
$tryAward = $row[0];
if($tryAward>5){
	echo '{"res":-3,"msg":"你填写错误信息太多次了"}';
	exit;
}

$username = addslashes($_POST['username']);
$tel      = addslashes($_POST['tel']);
// $member   = addslashes($_POST['member']);
$email    = addslashes(strtolower($_POST['email']));

$hasError = false;
$strError = '';

//$username = '金炯';
//$tel = '34343333343';
//$email = 'jojo.jin@philips.com';


if(mb_strlen($username,'utf-8')<=0||mb_strlen($username,'utf-8')>30){
	$hasError = true;
	$strError .= '姓名为空或多于30字.';
}

// if(mb_strlen($member,'utf-8')<=0||mb_strlen($member,'utf-8')>30){
//   $hasError = true;
//   $strError .= '工号为空或多于30字.';
// }

$pattern = '/^\\d{11}$/';
if(!preg_match($pattern, $tel ) ){
	$hasError = true;
	$strError .= '手机格式不对.';
}

$pattern_email = '/^\\w+((-\\w+)|(\\.\\w+))*\\@philips\\.com$/';
if(!preg_match($pattern_email,$email)){
	$hasError = true;
	$strError .= '电子邮件格式不对';
}

if($hasError){
	echo '{"res":-2,"msg":"'.$strError.'"}';
	exit;
}

$sql = "select id from cny1701_employee where username='$username' and email='$email'";
$result = mysql_query($sql);
$num_rows = mysql_num_rows($result);
if($num_rows==0){
	$sql = "insert into cny2017_save_log(userId, username, tel, email, award_type, award_id) values($userId, '$username', '$tel', '$email', $awardType, $awardId)";
	$result = mysql_query($sql);
	echo '{"res":-2,"msg":"非飞利浦员工"}';
	exit;
}


//检查当前用户信息是否中过
$sql = "select id from cny2017_award where username='$username' and email='$email'";
$result = mysql_query($sql);
$num_rows = mysql_num_rows($result);
if($num_rows>0){
	resetAward($awardType, $awardId);
	echo '{"res":-3,"msg":"该员工已经中过奖了。"}';
	exit;
}

$sql = "insert into cny2017_award(userId, username, tel, email, award_type, award_id) values($userId, '$username', '$tel', '$email', $awardType, $awardId)";
$result = mysql_query($sql);
if($result!==false){
	$awardData = $awardType==1?'cny1701_product_test':$redData;
	$sql = "update $awardData set is_use=1 where id=$awardId";
	mysql_query($sql);
	//发红包
	if($awardType==2){
		sendRed($openid, $award);
	}

	if($awardType==2){
		$num = 14;
	}else{
		$num = $award;
	}
	prefixSession('awardType', null);
	prefixSession('awardId', null);
	prefixSession('award', null);

	echo '{"res":1,"num":"'.$num.'","msg":"保存信息成功"}';
	exit;

}else{
	echo '{"res":-1,"msg":"保存信息出错，请重试。"}';
	exit;
}

function sendRed($openid, $award){
	//发红包
	$param = array(
		"nonce_str" => \WxPayApi::getNonceStr(),//随机字符串
		"mch_billno" => \WxPayConfig::MCHID . date('YmdHis') . rand(1000, 9999),//订单号
		"mch_id" => \WxPayConfig::MCHID,//商户号
		"wxappid" => \WxPayConfig::APPID,
		"send_name" => '飞利浦中国',//红包发送者名称
		"re_openid" => $openid,  //$openid  //o5ON-uA94b4IpqVRjj4mJSCmnHsQ  (kk)  //oV1qYwG7VmGj6ujKXt_-wnsMtv04
		"total_amount" => $award,//付款金额，单位分
		"total_num" => 1,//红包发放总人数
		"wishing" => '手气真好',//红包祝福语
		"scene_id" => 'PRODUCT_4',//场景id
		"client_ip" => '127.0.0.1',//调用接口的机器 Ip 地址
		"act_name" => '新年礼包',//活动名称
		"remark" => '快来抢！',//备注信息
	);
	$wxMchPayHelper = new \WxMchPayHelper($param);
	$xml = $wxMchPayHelper->send_redpack();
	//var_dump( $xml );
	if($xml->result_code=='SUCCESS'){


	}else{
		echo '{"res":-1,"msg":"发红包出错，请联系管理员。"}';
		exit;
	}

}


function resetAward($awardType, $awardId){
	if(empty($awardType)||empty($awardId)) return;

	$awardData = $awardType==1?'cny1701_product_test':$redData;
	$sql = "update $awardData set is_occupy=0, userId=0 where id=$awardId";
	mysql_query($sql);
}
