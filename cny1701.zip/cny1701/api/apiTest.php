<?php

include_once( 'config.php' );
include_once ("db.php");

$sql = 'insert into test(name,mobile) values("ttt","11111111111")';
$result = mysql_query($sql);
var_dump($result);