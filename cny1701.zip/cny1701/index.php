<?php
	include "api/config.php";
	include "api/auth.php";
?>
<!doctype html>
<html>
<head>
	<meta name="viewport" id="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">
	<meta content="yes" name="apple-mobile-web-app-capable">
	<meta content="black" name="apple-mobile-web-app-status-bar-style">
	<meta content="telephone=no" name="format-detection">
	<meta name="browsermode" content="application">
	<meta name="screen-orientation" content="portrait">
	<meta name="x5-page-mode" content="app">
	<meta name="x5-orientation" content="portrait">
	<meta name="renderer" content="webkit">
	<meta charset="utf-8">
	<title>新年大吉 飞来鸿运</title>


	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/swiper-3.3.1.min.css" />
	<link rel="stylesheet" href="css/main.css?v=1">

	<script>
		var _hmt = _hmt || [];
		(function() {
		  var hm = document.createElement("script");
		  hm.src = "https://hm.baidu.com/hm.js?0f19e01e8e48661af2f8b6c5306abbe2";
		  var s = document.getElementsByTagName("script")[0];
		  s.parentNode.insertBefore(hm, s);
		})();
	</script>
	<script>
	   var viewport = document.querySelector('#viewport')
	   var scale = window.screen.width/640
	   viewport.setAttribute('content','width=640,user-scalable=no,initial-scale=' + scale + ', minimum-scale=' + scale + ',maximum-scale=' + scale + ', target-densitydpi=device-dpi')
	 </script>

</head>
<body>
	<div id="all-container">
		<div class="logo hide"></div>
		<div class="rule hide">活动规则</div>
		<div class="music-icon on hide"></div>

		<!-- 开始页面 -->
		<div class="page1 page animated">
			<div class="page1-title-box animated">
				<img src="img/page1/2017.png" class="page1-2017">
				<img src="img/page1/title-txt.png" class="page1-txt">
				<img src="img/page1/pole.png" class="page1-pole">
				<img src="img/page1/zhongguojie.png" class="page1-knot-left">
				<img src="img/page1/zhongguojie.png" class="page1-knot-right">
			</div>
			<div class="page1-bottom">
				<div class="page1-bottom-left">
					<img src="img/page1/left-cloud.png" class="page1-left-cloud">
					<img src="img/page1/flower1.png" class="page1-flower1">
					<img src="img/page1/cloud.png" class="page1-cloud">
				</div>
				<div class="page1-bottom-right">
					<img src="img/page1/new-year.png" class="page1-new-year">
					<img src="img/page1/flower2.png" class="page1-flower2">
					<img src="img/page1/bottom-cloud.png" class="page1-bottom-cloud">
				</div>
			</div>
			<img src="img/page1/btn.png" class="page1-btn fadeIn animated">
		</div><!-- 开始页面介绍 -->

		<!-- 抽奖页面 -->
		<div class="page2 page animated hide">
			<div class="title-box">
				<img src="img/page2/title.png">
			</div>
			<div id="bags">
			  <div class="bag"></div>
			  <div class="bag"></div>
			  <div class="bag"></div>
			  <div class="bag"></div>
			  <div class="bag"></div>
			  <div class="bag"></div>
			  <div class="bag"></div>
			  <div class="bag"></div>
			</div>
			<div class="touch-icon-box">
				<img src="img/page2/touch-icon.png">
			</div>
		</div><!-- 抽奖页面结束 -->

		<!-- 领取奖品页面 -->
		<div class="page3 page animated">
			<div class="page3-title">
				<img src="img/page2/title.png">
			</div>

			<div class="prize-wrapper">
				<img src="img/page3/xianjin.png" class="prize1 hide">
				<img src="img/page3/kongqiguo.png" class="prize2 hide">
				<img src="img/page3/nengliangyi.png" class="prize3 hide">
				<img src="img/page3/jiqiren.png" class="prize4 hide">
				<img src="img/page3/liliaoyi.png" class="prize5 hide">
				<img src="img/page3/fugutixudao.png" class="prize6 hide">
				<img src="img/page3/chuifengji.png" class="prize7 hide">
				<img src="img/page3/dianfanbao.png" class="prize8 hide">
				<img src="img/page3/dianyundou.png" class="prize9 hide">
				<img src="img/page3/jiemianyi.png" class="prize10 hide">
				<img src="img/page3/jinghuaqi.png" class="prize11 hide">
				<img src="img/page3/liaoliji.png" class="prize12 hide">
				<img src="img/page3/tixudao.png" class="prize13 hide">
				<img src="img/page3/yashua.png" class="prize14 hide">
			</div>

			<div class="prize-info-box">
				<img src="img/page3/xianjin-title.png" class="prize-title1">
				<img src="img/page3/kongqiguo-title.png" class="prize-title2">
				<img src="img/page3/nengliangyi-title.png" class="prize-title3">
				<img src="img/page3/jiqiren-title.png" class="prize-title4">
				<img src="img/page3/liliaoyi-title.png" class="prize-title5">
				<img src="img/page3/fugutixudao-title.png" class="prize-title6">
				<img src="img/page3/chuifengji-title.png" class="prize-title7">
				<img src="img/page3/dianfanbao-title.png" class="prize-title8">
				<img src="img/page3/dianyundou-title.png" class="prize-title9">
				<img src="img/page3/jiemianyi-title.png" class="prize-title10">
				<img src="img/page3/jinghuaqi-title.png" class="prize-title11">
				<img src="img/page3/liaoliji-title.png" class="prize-title12">
				<img src="img/page3/tixudao-title.png" class="prize-title13">
				<img src="img/page3/yashua-title.png" class="prize-title14">
				<img src="img/close.png" class="prize-close">
				<div class="form">
					<div>
						<label for="name">姓名 : </label><input type="text" class="name" name="name" id="name" placeholder="（请输入中文姓名）" />
					</div>
					<div>
						<label for="tel">手机 : </label><input type="text" class="tel" name="tel" id="tel" placeholder="（130xxxx8888）" maxlength='11'/>
					</div>
					<div>
						<label for="email">邮箱 : </label><input type="text" class="email" name="email" id="email" placeholder="（请输入公司邮箱）" />
					</div>
				</div>
				<p class="prize-warn">*请完整填写以上员工信息，并确认提交以便领取奖品</p>
				<img src="img/page3/submit.png" class="page3-form-btn">
			</div>

			<div class="try-again-box hide">
				<img src="img/page4/try-again.png" class="try-again">
				<img src="img/close.png" class="prize-close1">
				<img src="img/page4/submit-again.png" class="submit-again">
			</div>

			<div class="back-info-box hide">
				<img src="img/page4/fail-info.png" class="fail-info">
				<p class="info-show hide"></p>
				<img src="img/close.png" class="prize-close1">
			</div>

			<div class="page3-btn-box">
				<img src="img/page3/btn.png">
			</div>

		</div><!-- 领取奖品页面结束 -->

		<!-- 立即送祝福页面 -->
		<div class="page4 page animated">
			<div class="page4-title">
				<img src="img/page2/title.png">
			</div>

			<div class="success-wrapper">
				<img src="img/page4/success.png" class="success-msg hide">
				<img src="img/page4/success-hongbao.png" class="success-hongbao-msg hide">
				<img src="img/page4/error.png" class="error-msg hide">
			</div>

			<div class="page4-btn-box">
				<img src="img/page4/btn.png">
			</div>
		</div><!-- 立即送祝福页面结束 -->

		<!-- 生成贺卡页面 -->
		<div class="page5 page animated">
			<div class="page5-title">
				<img src="img/page2/title.png">
			</div>

			<div class="container">
				<div class="input-box">
					<label for="self-name">（请输入姓名）</label>
					<i class="arrow"></i>
					<input type="text" id="self-name" class="self-name" name="self-name" placeholder="飞利浦" />
				</div>

				<div class="swiper-container">
				    <div class="swiper-wrapper">
				        <div class="swiper-slide" data-id='1'>
				        	<p class="slide-title slide-title1">
				        		<span>2017</span>
				        		<span class="slide-span">年年有余,饱享口福无油不胖</span>
				        	</p>
							<img src="img/page5/kongqiguo.png" class="slide1-img">
				        </div>
				        <div class="swiper-slide" data-id='2'>
				        	<p class="slide-title slide-title2">
				        		<span>2017</span>
				        		<span class="slide-span">告别疲劳,亮眼明目神采飞扬</span>
				        	</p>
							<img src="img/page5/nengliangyi.png"class="slide2-img">
				        </div>
				        <div class="swiper-slide" data-id='3'>
					        <p class="slide-title slide-title3">
					        	<span>2017</span>
					        	<span class="slide-span">扫除霉运,福气盈门除旧迎新</span>
					        </p>
							<img src="img/page5/jiqiren.png" class="slide3-img">
				        </div>
				        <div class="swiper-slide" data-id='4'>
					        <p class="slide-title slide-title4">
					        	<span>2017</span>
					        	<span class="slide-span">自由自在,热力不减青春永驻</span>
					        </p>
							<img src="img/page5/liliaoyi.png" class="slide4-img">
				        </div>
				        <div class="swiper-slide" data-id='5'>
					        <p class="slide-title slide-title5">
					        	<span>2017</span>
					        	<span class="slide-span">原力加持,时刻充满战斗力</span>
					        </p>
							<img src="img/page5/fugutixudao.png" class="slide5-img">
				        </div>
				        <div class="swiper-slide" data-id='6'>
					        <p class="slide-title slide-title6">
					        	<span>2017</span>
					        	<span class="slide-span">秀发水润,鸿运当头万事顺意</span>
					        </p>
							<img src="img/page5/chuifengji.png" class="slide6-img">
				        </div>
				        <div class="swiper-slide" data-id='7'>
					        <p class="slide-title slide-title7">
					        	<span>2017</span>
					        	<span class="slide-span">阖家欢乐,智芯好饭共享团圆</span>
					        </p>
							<img src="img/page5/dianfanbao.png" class="slide7-img">
				        </div>
				        <div class="swiper-slide" data-id='8'>
					        <p class="slide-title slide-title8">
					        	<span>2017</span>
					        	<span class="slide-span">扫平障碍,步步高升前途光明</span>
					        </p>
							<img src="img/page5/dianyundou.png" class="slide8-img">
				        </div>
				        <div class="swiper-slide" data-id='9'>
					        <p class="slide-title slide-title9">
					        	<span>2017</span>
					        	<span class="slide-span">实力净展,无惧挑战面面俱到</span>
					        </p>
							<img src="img/page5/jiemianyi.png" class="slide9-img">
				        </div>
				        <div class="swiper-slide" data-id='10'>
					        <p class="slide-title slide-title10">
					        	<span>2017</span>
					        	<span class="slide-span">自在呼吸,纯净空气天天安心蓝</span>
					        </p>
							<img src="img/page5/jinghuaqi.png" class="slide10-img">
				        </div>
				        <div class="swiper-slide" data-id='11'>
					        <p class="slide-title slide-title11">
					        	<span>2017</span>
					        	<span class="slide-span">破壁能量,补足营养更有活力</span>
					        </p>
							<img src="img/page5/liaoliji.png" class="slide11-img">
				        </div>
				        <div class="swiper-slide" data-id='12'>
					        <p class="slide-title slide-title12">
					        	<span>2017</span>
					        	<span class="slide-span">腔调在手,引领时尚有型就秀</span>
					        </p>
							<img src="img/page5/tixudao.png" class="slide12-img">
				        </div>
				        <div class="swiper-slide" data-id='13'>
					        <p class="slide-title slide-title13">
					        	<span>2017</span>
					        	<span class="slide-span">净齿亮白,笑口常开魅力自信</span>
					        </p>
							<img src="img/page5/yashua.png" class="slide13-img">
				        </div>
				    </div>
				    <!-- Add Pagination -->
				    <div class="swiper-pagination"></div>
				    <!-- Add Arrows -->
				    <div class="swiper-button-next"></div>
				    <div class="swiper-button-prev"></div>
				</div>
			</div>

			<div class="page5-btn-box">
				<img src="img/page5/btn.png">
			</div>
		</div><!-- 生成贺卡页面结束 -->

		<!-- 给朋友拜年页面 -->
		<div class="page6 page animated">
			<img src="img/page6/module.png" class="module">
			<img src="img/page6/title.png" class="page6-title">
			<p class="page6-txt">
				<span class="span1">飞利浦</span>
				<span>祝您</span>
			</p>
			<div class="product1 product hide">
				<img src="img/page6/kongqiguo-title.png" class="product-title1">
				<img src="img/page6/kongqiguo.png" class="page6-product-img1">
			</div>			
			<div class="product2 product hide">
				<img src="img/page6/nengliangyi-title.png" class="product-title2">
				<img src="img/page6/nengliangyi.png" class="page6-product-img2">
			</div>
			<div class="product3 product hide">
				<img src="img/page6/jiqiren-title.png" class="product-title3">
				<img src="img/page6/jiqiren.png" class="page6-product-img3">
			</div>
			<div class="product4 product hide">
				<img src="img/page6/liliaoyi-title.png" class="product-title4">
				<img src="img/page6/liliaoyi.png" class="page6-product-img4">
			</div>
			<div class="product5 product hide">
				<img src="img/page6/fugutixudao-title.png" class="product-title5">
				<img src="img/page6/fugutixudao.png" class="page6-product-img5">
			</div>
			<div class="product6 product hide">
				<img src="img/page6/chuifengji-title.png" class="product-title6">
				<img src="img/page6/chuifengji.png" class="page6-product-img6">
			</div>
			<div class="product7 product hide">
				<img src="img/page6/dianfanbao-title.png" class="product-title7">
				<img src="img/page6/dianfanbao.png" class="page6-product-img7">
			</div>
			<div class="product8 product hide">
				<img src="img/page6/dianyundou-title.png" class="product-title8">
				<img src="img/page6/dianyundou.png" class="page6-product-img8">
			</div>
			<div class="product9 product hide">
				<img src="img/page6/jiemianyi-title.png" class="product-title9">
				<img src="img/page6/jiemianyi.png" class="page6-product-img9">
			</div>
			<div class="product10 product hide">
				<img src="img/page6/jinghuaqi-title.png" class="product-title10">
				<img src="img/page6/jinghuaqi.png" class="page6-product-img10">
			</div>
			<div class="product11 product hide">
				<img src="img/page6/liaoliji-title.png" class="product-title11">
				<img src="img/page6/liaoliji.png" class="page6-product-img11">
			</div>
			<div class="product12 product hide">
				<img src="img/page6/tixudao-title.png" class="product-title12">
				<img src="img/page6/tixudao.png" class="page6-product-img12">
			</div>
			<div class="product13 product hide">
				<img src="img/page6/yashua-title.png" class="product-title13">
				<img src="img/page6/yashua.png" class="page6-product-img13">
			</div>
			<img src="img/page6/btn.png" class="page6-btn">
		</div><!-- 给朋友拜年页面结束 -->

		<!-- 说明 -->
		<p class="explain hide">*仅限飞利浦健康生活大中华区员工</p>

		<!-- 活动规则信息 -->
		<div class="rule-detail-box animated">
			<h3>活动规则</h3>
			<div class="rule-txt-box">
				<img src="img/rule-txt.png" class="rule-txt">
			</div>
			<div class="rule-detail-close"></div>
		</div>

		<!-- 分享提示 -->
		<div class="share-info-box">
			<img src="img/share-info.png">
		</div>

		<!-- progress -->
		<div class="progress">
			<span></span>
		</div>

		<!-- loader -->
		<div class="loader"></div>

		<!-- 覆盖层 -->
		<div class="cover"></div>

		<!-- 背景音乐 -->
		<audio src="music/music.mp3" loop="loop" id="audio" preload="auto"></audio>
	</div>

	<script>
		function audioAutoPlay(id) {
			var audio = document.getElementById(id);
			audio.play();
			document.addEventListener('WeixinJSBridgeReady',function() {
				audio.play();
			},false);
		}

		audioAutoPlay('audio');
	</script>

	<script src="js/jquery-2.1.4.min.js"></script>
	<script src="js/utils.js"></script>
	<script src="js/TweenMax.min.js"></script>
	<script src="js/swiper-3.4.0.min.js"></script>
	<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
	<script src="js/js.cookie.js"></script>
	<script src="js/config.js?v=1"></script>
	<script src="js/track.js"></script>
	<script src="js/share.js"></script>
	<script src="js/app.min.js?v=1"></script>

</body>
</html>
