var shareURL = 'http://2016conference.8060608.com/cny1701/';

var shareData = {
	title: '飞利浦祝您新年大吉,飞来鸿运',
	desc: '加入飞利浦会员，享健康新年',
	link: shareURL,
	imgUrl: 'http://2016conference.8060608.com/cny1701/img/share.jpg',
	success: function (res) {
		_hmt.push(['_trackEvent', '分享成功', '分享成功']);
	}
};

var shareData2 = {
	title: shareData.title,
	desc: shareData.desc,
	link: shareData.link,
	imgUrl: shareData.imgUrl,
	success: shareData.success,
	cancel: shareData.cancel,
	fail: shareData.fail
};