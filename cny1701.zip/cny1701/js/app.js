(function( $, win, track, utils, TweenMax, Swiper ) {
	var app = win.app = {};
	var _click = 'ontouchend' in win ? 'touchend' : 'click';
	app.loader = $('.loader');
	app.page1 = $('.page1');
	app.page2 = $('.page2');
	app.page3 = $('.page3');
	app.page4 = $('.page4');
	app.page5 = $('.page5');
	app.page6 = $('.page6');
	app.timeNum = 0;
	app.getAward = false;
	app.musicIcon = $('.music-icon');

	app.imgsArr = [
		'img/close.png','img/logo.png','img/music-icon.png',
		'img/rule-bg.png','img/rule-txt.png','img/share-info.png',
		'img/share.jpg',
		'img/page1/bg.jpg','img/page1/btn.png',
		'img/page1/title-txt.png','img/page1/2017.png','img/page1/bottom-cloud.png',
		'img/page1/cloud.png','img/page1/flower1.png','img/page1/flower2.png',
		'img/page1/left-cloud.png','img/page1/new-year.png','img/page1/pole.png',
		'img/page1/zhongguojie.png',
		'img/page2/bag.png','img/page2/bg.jpg',
		'img/page2/title.png','img/page2/touch-icon.png',
		'img/page3/bg.jpg',
		'img/page3/btn.png','img/page3/kongqiguo.png','img/page3/kongqiguo-title.png',
		'img/page3/prize-bg.png','img/page3/submit.png','img/page3/xianjin.png',
		'img/page3/xianjin-title.png','img/page3/fugutixudao.png',
		'img/page3/fugutixudao-title.png','img/page3/jiqiren.png','img/page3/jiqiren-title.png',
		'img/page3/nengliangyi.png','img/page3/nengliangyi-title.png','img/page3/liliaoyi.png','img/page3/liliaoyi-title.png',
		'img/page3/chuifengji.png','img/page3/chuifengji-title.png','img/page3/dianfanbao.png',
		'img/page3/dianfanbao-title.png','img/page3/dianyundou.png','img/page3/dianyundou-title.png',
		'img/page3/jiemianyi.png','img/page3/jiemianyi-title.png','img/page3/jinghuaqi.png',
		'img/page3/jinghuaqi-title.png','img/page3/liaoliji.png','img/page3/liaoliji-title.png',
		'img/page3/tixudao.png','img/page3/tixudao-title.png','img/page3/yashua.png',
		'img/page3/yashua-title.png',
		'img/page4/btn.png','img/page4/success.png','img/page4/error.png',
		'img/page4/back-info.png','img/page4/back-info-bg.png',
		'img/page4/submit-again.png','img/page4/success-hongbao.png','img/page4/try-again.png',
		'img/page4/try-again-bg.png',
		'img/page5/btn.png','img/page5/fugutixudao.png','img/page5/jiqiren.png',
		'img/page5/kongqiguo.png','img/page5/left-right.png','img/page5/nengliangyi.png',
		'img/page5/template.png','img/page5/liliaoyi.png','img/page5/chuifengji.png',
		'img/page5/dianfanbao.png','img/page5/dianyundou.png','img/page5/jiemianyi.png',
		'img/page5/jinghuaqi.png','img/page5/liaoliji.png','img/page5/tixudao.png',
		'img/page5/yashua.png',
		'img/page6/bg.jpg','img/page6/btn.png','img/page6/fugutixudao.png',
		'img/page6/module.png','img/page6/jiqiren.png','img/page6/kongqiguo.png',
		'img/page6/nengliangyi.png','img/page6/title.png',
		'img/page6/liliaoyi.png','img/page6/logo-dao.png','img/page6/bottom-title.png',
		'img/page6/fugutixudao-title.png','img/page6/jiqiren-title.png','img/page6/kongqiguo-title.png',
		'img/page6/nengliangyi-title.png','img/page6/liliaoyi-title.png','img/page6/chuifengji.png',
		'img/page6/chuifengji-title.png','img/page6/dianfanbao.png','img/page6/dianfanbao-title.png',
		'img/page6/dianyundou.png','img/page6/dianyundou-title.png','img/page6/jiemianyi.png',
		'img/page6/jiemianyi-title.png','img/page6/jinghuaqi.png','img/page6/jinghuaqi-title.png',
		'img/page6/liaoliji.png','img/page6/liaoliji-title.png','img/page6/tixudao.png',
		'img/page6/tixudao-title.png','img/page6/yashua.png','img/page6/yashua-title.png'
	];

	function loader(imgsArr) {
		var total = imgsArr.length,
			count = 0,
			percent = 0;
		for(var i in imgsArr) {
			var item = imgsArr[i];
			var img = new Image();

			img.onload = function() {
				if( count == total - 1 ) {
					$('.progress').fadeOut();
					$('.logo').removeClass('hide');
					$('.rule').removeClass('hide');
					$('.explain').removeClass('hide');
					app.musicIcon.removeClass('hide');
					app.page1.show();
					$('.explain').css({
						'top': 802 + 'px'
					});
				}

				percent = Math.ceil( count / (total - 1) * 100) + '%';
				var $progressSpan = $('.progress').find('span');
				$progressSpan.html(percent);
				var $progressSpanW = parseInt($progressSpan.css('width')) + 1;
				$progressSpan.css({
					'margin-left': '-' + ($progressSpanW/2) + 'px'
				});
				count++;
			};

			img.src = item;
		}
	}

	loader(app.imgsArr);

	app.init = function() {
		app.initMusic();
		app.rotate();
		app.ruleShow();
		app.ruleHide();
		app.parentHide();
		app.turnPage();
		app.clickBag();
		app.bless();
		app.makeCard();
		app.shareInfoShowOrHide();
		app.changePro();
	};

	app.turnPage = function() {
		var $page1Btn = $('.page1-btn');
		$page1Btn.on( _click, function() {
			track.trackEvent('开启好运-page1');
			app.page1.hide();
			$('.explain').css({
				'top': 964 + 'px'
			});
			app.page2.show();
		});
	};

	app.ruleShow = function() {
		var $rule = $('.rule');
		app.cover = $('.cover');
		app.ruleDetail = $('.rule-detail-box');
		$rule.on( _click, function() {
			track.trackEvent('查看活动规则');
			app.cover.fadeIn();
			app.ruleDetail.fadeIn();
		});
	};

	app.ruleHide = function() {
		var $ruleClose = $('.rule-detail-close');
		$ruleClose.on( _click, function() {
			track.trackEvent('关闭活动规则');
			app.cover.fadeOut();
			app.ruleDetail.fadeOut();
		});
	};

	app.formClose = function() {
		var $prizeClose = $('.prize-close');
		app.prizeInfo = $('.prize-info-box');
		$prizeClose.on(_click, function() {
			app.prizeInfo.fadeOut();
			app.cover.fadeOut();
		});
	};

	app.formShow = function() {
		var $page3Btn = $('.page3-btn-box');
		$page3Btn.on(_click, function() {
			track.trackEvent('立即领取-page3');
			app.cover.fadeIn();
			app.prizeInfo.fadeIn();
		});
	};

	app.parentHide = function() {
		var $prizeClose1 = $('.prize-close1');
		$prizeClose1.on(_click,function() {
			app.cover.fadeOut();
			$(this).parent().addClass('hide');
		});
	};

	function isName(name) {
		var pattern = /^.{2,30}$/;
		return pattern.test(name);
	}

	function isPhoneNo(tel) {
		var pattern = /^1\d{10}$/;
		return pattern.test(tel);
	}

	function isEmail(email) {
		var pattern = /^\w+((-\w+)|(\.\w+))*@philips\.com$/i;
		return pattern.test(email);
	}

	app.submitInfo = function() {
		var $page3FormBtn = $('.page3-form-btn');
		var $form = $('.form');

		var isSubmit = false;
		$page3FormBtn.on(_click, function() {
			var str = '';
			var name = $('#name').val();
			var tel = $('#tel').val();
			var email = $('#email').val();

			if( isName( $.trim(name) ) == false ) {
				str += '请输入姓名\n';
				$('#name').focus();
			}

			if( $.trim(tel).length == 0 ) {
				str += '请输入手机号码\n';
				$('#tel').focus();
			} else if( isPhoneNo($.trim(tel)) == false ) {
				str += '请输入正确的手机号码\n';
				$('#tel').focus();
			}

			if( isEmail( $.trim(email) ) == false ) {
				str += '请输入正确的Email\n';
				$('#email').focus();
			}

			if( str != '' ) {
				utils.showTip(str,{seconds: 1500});
				return false;
			}

			if( isSubmit ) {
				return false;
			}
			isSubmit = true;

			track.trackEvent('提交中奖信息-page3');


			
			var data = {
				username: name,
				tel: tel,
				email: email
			};

			var $successWrapper = $('.success-wrapper');

			// -2是非飞利浦
			// -1是其他原因，显示后台文字，msg
			$.ajax({
				type: "post",
				url: "api/apiSaveAward.php",
				dataType: "json",
				data: data
			}).done(function(data){
				if( data.res == 1 ) {
					app.getAward = true;
					localStorage.setItem('getAward2',app.getAward);
					
					$('#name').val('');
					$('#tel').val('');
					$('#email').val('');
					Utils.showTip(data.msg,{seconds:700});
					app.page3.fadeOut();
					app.cover.fadeOut();
					$successWrapper.show();
					if( data.num == 14 ) {
						var $successHBMsg = $('.success-hongbao-msg');
						$successHBMsg.removeClass('hide');
						app.page4.fadeIn();
					} else {
						var $successMsg = $('.success-msg');
						$successMsg.removeClass('hide');
						app.page4.fadeIn();
					}

				}else if(data.res == -2) {
					app.timeNum += 1;
					localStorage.setItem('timeNum2',app.timeNum);
					var $tryAgainBox = $('.try-again-box');
					var $tryAgain = $('.try-again');
					var $submitAgain = $('.submit-again');
					app.prizeInfo.fadeOut();
					$tryAgainBox.removeClass('hide');
					$tryAgain.removeClass('hide');

					$submitAgain.on(_click, function() {
						track.trackEvent('重新提交-page3');
						var timeNum = parseInt(localStorage.getItem('timeNum2'));
						var $backInfo = $('.back-info-box');
						var $failInfo = $('.fail-info');
						if( timeNum > 3 ) {
							$tryAgainBox.addClass('hide');
							$tryAgain.addClass('hide');
							$backInfo.removeClass('hide');
							$failInfo.show();
							setTimeout(function() {
								app.cover.fadeOut();
								app.page3.fadeOut();
								app.page1.show();
								$('.explain').css({
									'top': 802 + 'px'
								});
							},2000);
						} else {
							$tryAgainBox.addClass('hide');
							$tryAgain.addClass('hide');
							app.prizeInfo.fadeIn();
						}
					});
				}else if( data.res == -1 ) {
					var $infoShow = $('.info-show');
					var $backInfo = $('.back-info-box');
					app.prizeInfo.fadeOut();
					$infoShow.html(data.msg);
					$infoShow.removeClass('hide');
					$backInfo.removeClass('hide');
					setTimeout(function() {
						app.cover.fadeOut();
						app.page3.fadeOut();
						$infoShow.addClass('hide');
						app.page1.show();
						$('.explain').css({
							'top': 802 + 'px'
						});
					},2000);
				} else if( data.res == -3 ) {
					utils.showTip(data.msg,{seconds: 1500});
					app.prizeInfo.fadeOut();
					app.cover.fadeOut();
					app.page2.hide();
					app.page5.css({
						'visibility': 'visible',
					});
				}

				isSubmit = false;
			});
		});
	};

	app.clickBag = function() {
		var $bags = $('.bag');
		var $prizeWrapper = $('.prize-wrapper');
		var $backInfo = $('.back-info-box');
		var $infoShow = $('.info-show');
		var $prize1 = $('.prize1');
		var $prizeTitle1 = $('.prize-title1');
		var $prize2 = $('.prize2');
		var $prizeTitle2 = $('.prize-title2');
		var $prize3 = $('.prize3');
		var $prizeTitle3 = $('.prize-title3');
		var $prize4 = $('.prize4');
		var $prizeTitle4 = $('.prize-title4');
		var $prize5 = $('.prize5');
		var $prizeTitle5 = $('.prize-title5');
		var $prize6 = $('.prize6');
		var $prizeTitle6 = $('.prize-title6');
		var $prize7 = $('.prize7');
		var $prizeTitle7 = $('.prize-title7');
		var $prize8 = $('.prize8');
		var $prizeTitle8 = $('.prize-title8');
		var $prize9 = $('.prize9');
		var $prizeTitle9 = $('.prize-title9');
		var $prize10 = $('.prize10');
		var $prizeTitle10 = $('.prize-title10');
		var $prize11 = $('.prize11');
		var $prizeTitle11 = $('.prize-title11');
		var $prize12 = $('.prize12');
		var $prizeTitle12 = $('.prize-title12');
		var $prize13 = $('.prize13');
		var $prizeTitle13 = $('.prize-title13');
		var $prize14 = $('.prize14');
		var $prizeTitle14 = $('.prize-title14');
		$bags.each(function() {
			$(this).on( _click, function() {
				track.trackEvent('抽红包-page2');
				$prizeWrapper.fadeOut();
				$backInfo.addClass('hide');
				$infoShow.addClass('hide');
				$prize1.addClass('hide');
				$prizeTitle1.fadeOut();
				$prize2.addClass('hide');
				$prizeTitle2.fadeOut();
				$prize3.addClass('hide');
				$prizeTitle3.fadeOut();
				$prize4.addClass('hide');
				$prizeTitle4.fadeOut();
				$prize5.addClass('hide');
				$prizeTitle5.fadeOut();
				$prize6.addClass('hide');
				$prizeTitle6.fadeOut();
				$prize7.addClass('hide');
				$prizeTitle7.fadeOut();
				$prize8.addClass('hide');
				$prizeTitle8.fadeOut();
				$prize9.addClass('hide');
				$prizeTitle9.fadeOut();
				$prize10.addClass('hide');
				$prizeTitle10.fadeOut();
				$prize11.addClass('hide');
				$prizeTitle11.fadeOut();
				$prize12.addClass('hide');
				$prizeTitle12.fadeOut();
				$prize13.addClass('hide');
				$prizeTitle13.fadeOut();
				$prize14.addClass('hide');
				$prizeTitle14.fadeOut();
				app.cover.show();
				app.loader.show();
				var getAward = localStorage.getItem('getAward2');
				var timeNum = parseInt(localStorage.getItem('timeNum2'));
				if( timeNum > 3 ) {
					var $errorMsg = $('.error-msg');
					var $successWrapper = $('.success-wrapper');
					app.page2.hide();
					app.cover.hide();
					app.loader.hide();
					$successWrapper.show();
					$errorMsg.removeClass('hide');
					app.page4.fadeIn();
					return;
				} else if( getAward ) {
					utils.showTip('您已中过奖!',{seconds: 1500});
					app.page2.hide();
					app.cover.hide();
					app.loader.hide();
					app.page5.css({
						'visibility': 'visible'
					});
					return false;
				} else {
					$.ajax({
						type: 'get',
						url: "api/apiGetAward.php",
						dataType: "json"
					}).done(function(data){
						// res=1成功，中奖
						// 未中奖-1
						// 中过奖-2
						if( data.res == -2 ) {
							utils.showTip(data.msg,{seconds: 1500});
							app.cover.fadeOut();
							app.loader.fadeOut();
							app.page2.hide();
							app.page5.css({
								'visibility': 'visible'
							});
							return false;
						} else if( data.res == 1 ) {
							app.cover.fadeOut();
							app.loader.fadeOut();
							app.page2.hide();
							app.page3.fadeIn();
							
							$prizeWrapper.fadeIn();
							if( data.num == 14 ) {
								$prize1.removeClass('hide');
								$prizeTitle1.fadeIn();
							} else if( data.num == 5 ) {
								$prize2.removeClass('hide');
								$prizeTitle2.fadeIn();
							} else if ( data.num == 1 ) {
								$prize3.removeClass('hide');
								$prizeTitle3.fadeIn();
							} else if ( data.num == 4 ) {
								$prize4.removeClass('hide');
								$prizeTitle4.fadeIn();
							} else if ( data.num == 6 ) {
								$prize5.removeClass('hide');
								$prizeTitle5.fadeIn();
							} else if( data.num == 7 ) {
								$prize6.removeClass('hide');
								$prizeTitle6.fadeIn();
							} else if( data.num == 8 ) {
								$prize12.removeClass('hide');
								$prizeTitle12.fadeIn();
							} else if( data.num == 9 ) {
								$prize8.removeClass('hide');
								$prizeTitle8.fadeIn();
							} else if( data.num == 10 ) {
								$prize10.removeClass('hide');
								$prizeTitle10.fadeIn();
							} else if( data.num == 11 ) {
								$prize14.removeClass('hide');
								$prizeTitle14.fadeIn();
							} else if( data.num == 12 ) {
								$prize13.removeClass('hide');
								$prizeTitle13.fadeIn();
							} else if ( data.num == 2 ) {
								$prize7.removeClass('hide');
								$prizeTitle7.fadeIn();
							} else if( data.num == 3 ) {
								$prize11.removeClass('hide');
								$prizeTitle11.fadeIn();
							} else if( data.num == 13 ) {
								$prize9.removeClass('hide');
								$prizeTitle9.fadeIn();
							}
							app.formShow();
							app.formClose();
							app.submitInfo();
						} else if( data.res == -1 ) {
							
							$infoShow.html(data.msg);
							app.page2.hide();
							app.loader.hide();
							$infoShow.removeClass('hide');
							app.page3.fadeIn();

							$backInfo.removeClass('hide');
							setTimeout(function() {
								app.cover.fadeOut();
								app.page3.fadeOut();
								app.page1.show();
								$('.explain').css({
									'top': 802 + 'px'
								});
							},2000);
						}
						
					});
				}
			});
		});
	};

	app.bless = function() {
		var $page4Btn = $('.page4-btn-box');
		$page4Btn.on(_click, function() {
			track.trackEvent('立即送祝福-page4');
			app.page4.fadeOut();
			app.page5.css({
				'visibility': 'visible',
			});
		});
	};

	app.makeCard = function() {
		$page5Btn = $('.page5-btn-box');
		$('#self-name').focus(function() {
			$(this).attr('placeholder','');
		});
		$('#self-name').blur(function() {
			$(this).attr('placeholder','飞利浦');
		});
		$page5Btn.on(_click, function() {
			track.trackEvent('生成贺卡-page5');
			app.selfName = $('#self-name').val();
			if( $.trim(app.selfName) == '' ) {
				app.selfName = '飞利浦';
			}

			var parseURL = function (url) {
				var a =  document.createElement('a');
				a.href = url;
				return {
					source: url,
					protocol: a.protocol.replace(':',''),
					host: a.hostname,
					port: a.port,
					query: a.search,
					params: (function(){
						var ret = {},
							seg = a.search.replace(/^\?/,'').split('&'),
							len = seg.length, i = 0, s;
						for (;i<len;i++) {
							if (!seg[i]) { continue; }
							s = seg[i].split('=');
							ret[s[0]] = s[1];
						}
						return ret;
					})(),
					file: (a.pathname.match(/\/([^\/?#]+)$/i) || [,''])[1],
					hash: a.hash.replace('#',''),
					path: a.pathname.replace(/^([^\/])/,'/$1'),
					relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [,''])[1],
					segments: a.pathname.replace(/^\//,'').split('/')
				};
			};

			var hmsr,share,userid;
			var myURL = parseURL(location.href);
			hmsr = myURL.params.hmsr;
			userid = myURL.params.userid;
			share = parseInt(myURL.params.share,10);
			if(!isNaN(share)){
				share++;
			}
			if(!hmsr){
				hmsr = Cookies.get('hmsr')?Cookies.get('hmsr'):0;
			}
			if(!share){
				share = Cookies.get('share')?parseInt(Cookies.get('share'),10):1;
			}
			userid && Cookies.set('hmsr', userid, { expires: 1, path: '' });
			userid && Cookies.set('share', share, { expires: 1, path: '' });

			var $swiperActive = $('.swiper-wrapper').find('.swiper-slide-active');
			app.choiceId = $swiperActive.data('id');
			app.blessTitle = $swiperActive.find('.slide-span').html();
			shareData2.title = shareData.title = app.selfName +'祝您2017' + app.blessTitle;
			var link = shareURL;
			shareData2.link = shareData.link = link + 'share.html'+'?hmsr='+hmsr+'&share='+share+'&choiceId=' + app.choiceId + '&selfName=' + app.selfName + '&blessTitle=' + app.blessTitle;
			app.page5.fadeOut();
			$('.explain').hide();
			var $productInfo = $('.product' + app.choiceId );
			$productInfo.removeClass('hide');
			$('.page6-txt').find('.span1').html(app.selfName);
			var $logo = $('.logo');
			$logo.removeClass('logo').addClass('logo-dao');
			$('.rule').addClass('hide');
			app.musicIcon.addClass('hide');
			app.page6.fadeIn();
		});
	};

	app.shareInfoShowOrHide = function() {
		var $page6Btn = $('.page6-btn');
		var $shareInfoBox = $('.share-info-box');
		$page6Btn.on(_click, function() {
			track.trackEvent('给朋友拜年-page6');
			$shareInfoBox.fadeIn();
		});

		$shareInfoBox.on(_click,function() {
			$(this).fadeOut();
		});
	};

	app.initMusic = function() {
		app.audio = $('#audio').get(0);
		app.musicIcon.on(_click,function() {
			if(app.audio.paused) {
				app.playMusic();
			} else {
				app.pauseMusic();
			}
		});
		app.audio.play();
	};

	app.pauseMusic = function() {
		app.audio.pause();
		app.musicIcon.removeClass('on').addClass('off');
	};

	app.playMusic = function() {
		app.audio.play();
		app.musicIcon.removeClass('off').addClass('on');
	};

	app.rotate = function() {
		var radiusX = 230, 
		    radiusY = 130;
		var bagElems = document.querySelectorAll('.bag');
		var elems = [].slice.call(bagElems),
		    total = elems.length,
		    radian = 2*Math.PI/total;
		var bags = [];

		function init() {
		  elems.forEach(function(bag, i) {
		    var r = radian * i;
		    var x = -72 + radiusX * Math.cos(r);
		    var y = radiusY * Math.sin(r);
		    var scale = (y + radiusY + 200) / (radiusY + 360),
		        scale = scale < 0.6 ? 0.6 : scale;
		    var index = Math.ceil(scale * 100);
		    TweenMax.set(bag, {
		      x: x,
		      y: y,
		      scale: scale,
		      zIndex: index,
		      force3D: true,
		    });
		    bags.push({
		      elem: bag,
		      radius: r
		    });
		  });
		  rotate();
		}
		function rotate() {
		  bags.forEach(function(bag) {
		    var r = bag.radius;
		    var x = -72 + radiusX * Math.cos(r);
		    var y = radiusY * Math.sin(r);
		    var scale = (y + radiusY + 200) / (radiusY + 360),
		        scale = scale < 0.6 ? 0.6 : scale;
		    var index = Math.ceil(scale * 100);
		    TweenMax.set(bag.elem, {
		      x: Math.floor(x),
		      y: Math.floor(y),
		      scale: round(scale),
		      zIndex: index,
		      force3D: true
		    });
		    bag.radius += 0.015;
		  });
		  requestAnimationFrame(rotate);
		}

		function round(v) {
		  return Math.floor(v * 100) / 100;
		}

		init();
	};

	app.changePro = function() {
		var swiper = new Swiper('.swiper-container', {
		    pagination: '.swiper-pagination',
		    paginationClickable: '.swiper-pagination',
		    nextButton: '.swiper-button-next',
		    prevButton: '.swiper-button-prev',
		    spaceBetween: 30
		});
	};

	
	$(function() {
		app.init();
	});
})(jQuery,window,Track,Utils,TweenMax,Swiper);