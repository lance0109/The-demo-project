//关闭顶部广告
function closeAdvTop(){
	document.getElementById("top-adv-01").style.display = "none";
}
//关闭底部广告
function closeAdvBottom(){
	document.getElementById("bottom-adv-02").style.display = "none";
}

//顶部展开nav
function expendTpNav(){
	var moreTop = document.getElementById("more_top");
	var moreTopParent = moreTop.parentElement;
	var packUpTop = document.getElementById("pack_top");
	moreTop.style.display = "none";
	packUpTop.style.display = "inline-block";
	moreTopParent.style.height = "90px";
}
//顶部收起nav
function packUpTpNav(){
	var packUpTop = document.getElementById("pack_top");
	var packUpTopParent = packUpTop.parentElement;
	var moreTop = document.getElementById("more_top");
	packUpTop.style.display = "none";
	moreTop.style.display = "inline-block";
	packUpTopParent.style.height = "60px";
}

//滚动资讯
function scrollLeft(){
	var scrollNews = document.getElementById("scroll-news");
	var scrollList = document.getElementById("scroll_list");
	var scrollBox = document.getElementById("scroll_box"); 
	scrollBox.innerHTML = scrollList.innerHTML;
	function marquee(){
		if(scrollNews.scrollLeft - scrollBox.offsetWidth >= 0){
			scrollNews.scrollLeft -= scrollList.offsetWidth;
		}else{
			scrollNews.scrollLeft++;
		}
	}
	var scrollTime = setInterval(marquee,30);
	scrollNews.onmouseout = function(){scrollTime}
	scrollNews.onmouseover = function(){clearInterval(scrollTime);}
}
scrollLeft();

//图片切换
$(function(){
	$firstLi = $("#scroll_adv li:first");
	$secondLi = $("#scroll_adv li:last");
	function autoShow(){
		if($firstLi.css("display") == "block"){
			$firstLi.css("display","none");
			$secondLi.css("display","block");
		}else{
			$firstLi.css("display","block");
			$secondLi.css("display","none");
		}
	}
	setInterval(autoShow,5000);
})


//底部展开nav
function expendBtNav(){
	var moreBt = document.getElementById("more_bottom");
	var moreBtParent = moreBt.parentElement;
	var packUpBt = document.getElementById("pack_bottom");
	moreBt.style.display = "none";
	packUpBt.style.display = "inline-block";
	moreBtParent.style.height = "90px";
}
//底部收起nav
function packUpBtNav(){
	var packUpBt = document.getElementById("pack_bottom");
	var packUpBtParent = packUpBt.parentElement;
	var moreBt = document.getElementById("more_bottom");
	packUpBt.style.display = "none";
	moreBt.style.display = "inline-block";
	packUpBtParent.style.height = "60px";
}