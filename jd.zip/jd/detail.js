function showServices(){
	document.getElementById('services').style.display = 'block';
	document.getElementById('servicetag').style.border = '1px solid #ddd';
	document.getElementById('servicetag').style.borderBottom = 'none';
	document.getElementById('servicetag').style.background = '#fff url(images/jt_up.jpg) right center no-repeat';
}
function hideServices(){
	document.getElementById('services').style.display = 'none';
	document.getElementById('servicetag').style.border = '1px solid transparent';
	document.getElementById('servicetag').style.background = 'transparent url(images/jt_down.jpg) right center no-repeat';
}
function showMobile_jditems(){
	document.getElementById('mobile_jditems').style.display = 'block';
	document.getElementById('mobile_jdparent').style.border = '1px solid #ddd';
	document.getElementById('mobile_jdparent').style.borderBottom = 'none';
	document.getElementById('mobile_jdparent').style.background = '#fff url(images/iconlist_2.png) -126px -397px no-repeat';
	document.getElementById('mobile_jdtag').style.background = '#fff url(images/jt_up.jpg) right center no-repeat';
}
function hideMobile_jditems(){
	document.getElementById('mobile_jditems').style.display = 'none';
	document.getElementById('mobile_jdparent').style.border = '1px solid transparent';
	document.getElementById('mobile_jdparent').style.background = '#fff url(images/iconlist_2.png) no-repeat -126px -358px';
	document.getElementById('mobile_jdtag').style.background = 'transparent url(images/jt_down.jpg) right center no-repeat';
}
function shownav(){
	document.getElementById('webnav_div').style.display = "block";
	document.getElementById('webnav').style.border = "1px solid #ddd";
	document.getElementById('webnav').style.borderBottom = "none";
	document.getElementById('webnav').style.background = "#fff url(images/jt_up.jpg) right center no-repeat";
}
function hidenav(){
	document.getElementById('webnav_div').style.display = "none";
	document.getElementById('webnav').style.border = "1px solid transparent";
	document.getElementById('webnav').style.background = "#fff url(images/jt_down.jpg) right center no-repeat";
}
