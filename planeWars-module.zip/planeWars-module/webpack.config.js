module.exports = {
	entry: './js/src/app.js',
	output: {
		path: './js/dist',
		filename: 'app.min.js'
	}
};