var createEnemyObj = {
	init: function() {
		this.interval = Math.random() * 1700 + 100;
		this.lastTime = 0;
		this.born = true;
	},

	createEnemy: function() {
		var curTime = Date.now();

		if( curTime - this.lastTime >= this.interval ) {
			if( this.born ) {
				app.enemies.push( new app.Enemy() );

				if( app.enemies.length >= 30 ) {
					this.born = false;
				}
			}
			
			if( app.enemies.length < 30) {
				this.born = true;
			}

			this.lastTime = curTime;
		}
	}
};

module.exports = createEnemyObj;