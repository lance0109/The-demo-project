var Enemy = function() {
	this.enemyImg = [];

	for( var i=0; i<5; i++ ) {
		this.enemyImg[i] = new Image();
		if( i < 1 ) {
			this.enemyImg[i].src = 'img/enemy' + ( i + 1 ) +'.png';
		} else {
			this.enemyImg[i].src = 'img/enemy1_down' + i + '.png';
		}
	}

	this.life = parseInt( Math.random() * 15 + 1 );
	this.score = this.life;

	if( app.SCORE >= 750 ) {
		this.spd = this.life * 0.1;
	} else if( app.SCORE >= 600 ) {
		this.spd = this.life * 1;
	} else if( app.SCORE >= 460 ) {
		this.spd = this.life * 1.8;
	} else if( app.SCORE >= 330 ) {
		this.spd = this.life * 2.6;
	} else if( app.SCORE >= 210 ) {
		this.spd = this.life * 3.4;
	} else if( app.SCORE >= 100 ) {
		this.spd = this.life * 4.2;
	} else if( app.SCORE < 100 ) {
		this.spd = this.life * 5;
	}

	this.width = 56;
	this.height = 52;

	this.x = Math.random() * ( app.canW - this.width);
	this.y = -this.height;

	this.picIndex = 0;
	this.lastTime = 0;

	this.blowDown = false;
	this.canDelete = false;

	this.sumScore = 0;

	this.pic = this.enemyImg[this.picIndex];
};

Enemy.prototype.step = function(  ) {
	var curTime = Date.now();

	if( curTime - this.lastTime > this.spd ) {
		if( this.blowDown ) {
			this.pic = this.enemyImg[this.picIndex];
			this.picIndex++;
			if( this.picIndex >= 5 ) {
				app.SCORE += this.score;
				this.canDelete = true;
			}
		} else {
			this.y++;
		}

		this.lastTime = curTime;
	}
};

Enemy.prototype.draw = function() {
	app.ctx.drawImage( this.pic, this.x, this.y );
};

Enemy.prototype.outOfBounds = function() {
	return this.y > app.canH;
};

Enemy.prototype.bang = function() {
	this.life--;
	if( this.life === 0 ) {
		this.blowDown = true;
	}
};

Enemy.prototype.hit = function( obj ) {
	return obj.x + obj.width / 2 > this.x + obj.width / 2 &&
		   obj.x + obj.width / 2 < this.x + this.width + obj.width / 2 &&
		   obj.y + obj.height / 2 > this.y - obj.height / 2 &&
		   obj.y + obj.height / 2 < this.y + this.height + obj.height / 2;
};

module.exports = Enemy;