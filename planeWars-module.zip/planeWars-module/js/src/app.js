(function(global) {
	var app = global.app = {};
	app.can = document.getElementById('canvas');
	app.ctx = app.can.getContext('2d');
	app.pause = document.getElementById('pause');

	var screenH = document.body.clientHeight;
	app.can.width = 640;
	app.can.height = screenH;

	app.canW = app.can.width;
	app.canH = screenH;

	// ×ÔÊÊÓ¦¸ß¶È
	global.onresize = function() {
		screenH = document.body.clientHeight;
		app.can.height = screenH;
	};

	app.bullets = [];
	app.enemies = [];

	app.SCORE = 0;
	app.START = 0;
	app.RUNNING = 1;
	app.PAUSE = 2;
	app.GAMEOVER = 3;
	app.state = app.START;

	app.init = function() {
		app.can.addEventListener( 'touchstart', touch, false);
		app.can.addEventListener( 'touchmove', touch, false);
		app.can.addEventListener( 'touchend', touch, false);

		app.can.addEventListener( 'click', mouse, false );
		app.can.addEventListener( 'mousemove', mouse, false );
		app.can.addEventListener( 'mouseover', mouse, false );
		app.can.addEventListener( 'mouseout', mouse, false);

		function touch( event ) {
			var e = event || global.event;
			e.preventDefault();

			if( e.type === 'touchstart' ) {
				if( app.state === app.START ) {
					app.state = app.RUNNING;
					app.hero.x = e.changedTouches[0].pageX - app.hero.width / 2;
					app.hero.y = e.changedTouches[0].pageY - app.hero.height / 2;
					app.Bullet.x = e.changedTouches[0].pageX;
					app.Bullet.y = e.changedTouches[0].pageY;
				}
			} else if( e.type === 'touchmove' ) {
				if( app.state === app.RUNNING ) {
					app.hero.x = e.changedTouches[0].pageX - app.hero.width / 2;
					app.hero.y = e.changedTouches[0].pageY - app.hero.height / 2;
					app.Bullet.x = e.changedTouches[0].pageX;
					app.Bullet.y = e.changedTouches[0].pageY;
				}
			} else if( e.type === 'touchend' ) {
				if( app.state === app.RUNNING ) {
					app.hero.x = e.changedTouches[0].pageX - app.hero.width / 2;
					app.hero.y = e.changedTouches[0].pageY - app.hero.height / 2;
					app.Bullet.x = e.changedTouches[0].pageX;
					app.Bullet.y = e.changedTouches[0].pageY;
				}
			}
		}

		function mouse( event ) {
			var e = event || global.event;
			e.preventDefault();

			if( e.type === 'click' ) {
				if( app.state === app.START ) {
					app.state = app.RUNNING;
					app.hero.x = e.offsetX - app.hero.width / 2;
					app.hero.y = e.offsetY - app.hero.height / 2;
					app.Bullet.x = e.offsetX;
					app.Bullet.y = e.offsetY;
				}
			} else if( e.type === 'mousemove' ) {
				if( app.state === app.RUNNING ) {
					app.hero.x = e.offsetX - app.hero.width / 2;
					app.hero.y = e.offsetY - app.hero.height / 2;
					app.Bullet.x = e.offsetX;
					app.Bullet.y = e.offsetY;
				}
			} else if( e.type === 'mouseout' ) {
				if( app.state === app.RUNNING ) {
					app.state = app.PAUSE;
					app.pause.style.backgroundImage = 'url(img/game_resume_nor.png)';
				}
			} else if( e.type === 'mouseover' ) {
				if( app.state === app.PAUSE ) {
					app.state = app.RUNNING;
					app.pause.style.backgroundImage = 'url(img/game_pause_nor.png)';
				}
			}
		}

		app.pause.addEventListener( 'touchstart', pauseOrCon, false );

		function pauseOrCon( event ) {
			var e = event || global.event;
			e.preventDefault();

			if( app.state === app.RUNNING ) {
				app.state = app.PAUSE;
				app.pause.style.backgroundImage = 'url(img/game_resume_nor.png)';
			} else if( app.state === app.PAUSE ) {
				app.state = app.RUNNING;
				app.pause.style.backgroundImage = 'url(img/game_pause_nor.png)';
			}
		}

		bg.init();
		app.hero.init();
		createEnemyObj.init();
	};

	app.gameLoop = function() {
		reqAnimFrame( app.gameLoop );

		switch( app.state ) {
			case app.START:
				 drawOther.drawEntry();
				 bg.step();
				 bg.draw();
				 break;

			case app.RUNNING:
				 bg.step();
				 bg.draw();
				 app.hero.step();
				 app.hero.shoot();
				 createEnemyObj.createEnemy();
				 drawBE.step();
				 drawBE.draw();
				 app.hero.draw();

				 checkHit();
				 canDelete();
				 drawOther.drawScore();
				 drawOther.drawLife();

				 app.pause.style.display = 'block';
				 break;

			case app.PAUSE:
				 bg.step();
				 bg.draw();
				 drawBE.draw();
				 app.hero.draw();
				 drawOther.drawScore();
				 drawOther.drawLife();
				 drawOther.drawPause();
				 break;

			case app.GAMEOVER:
				 drawOther.drawOver();
				 drawOther.drawLife();
				 break;
		}
	};

	app.game = function() {
		app.init();
		app.gameLoop();
	};

	global.onload = app.game;
	
	var reqAnimFrame = require('./plug');
	var bg = require('./bg');
	app.hero = require('./hero');
	app.Bullet = require('./bullet');
	app.Enemy = require('./enemy');
	var createEnemyObj = require('./createEnemy');
	var drawBE = require('./drawBE');
	var canDelete = require('./delete');
	var checkHit = require('./checkHit');
	var drawOther = require('./drawOther');
})(window);


