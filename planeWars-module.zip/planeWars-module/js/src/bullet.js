var Bullet = function() {
	this.bulletImg = new Image();
	this.bulletImg.src = 'img/bullet1.png';

	this.width = 9;
	this.height = 21;

	this.x = app.Bullet.x - Math.floor(this.width / 2);
	this.y = app.Bullet.y - Math.floor(this.height * 3.5);

	this.lastTime = 0;
	this.spd = 15;
	this.canDelete = false;
};

Bullet.prototype.step = function() {
	var curTime = Date.now();

	if( curTime - this.lastTime > this.spd ) {
		this.y -= 6;
		this.lastTime = curTime;
	}
};

Bullet.prototype.outOfBounds = function() {
	return this.y < -app.canH;
};

Bullet.prototype.draw = function() {
	app.ctx.drawImage( this.bulletImg, this.x, this.y );
};

module.exports = Bullet;