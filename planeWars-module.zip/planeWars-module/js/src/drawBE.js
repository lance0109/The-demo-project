var drawBE = {
	draw: function() {
		for( var i=0; i<app.enemies.length; i++ ) {
			app.enemies[i].draw();
		}

		for( var i=0; i<app.bullets.length; i++ ) {
			app.bullets[i].draw();
		}
	},

	step: function() {
		for( var i=0; i<app.enemies.length; i++ ) {
			app.enemies[i].step();
		}

		for( var i=0; i<app.bullets.length; i++ ) {
			app.bullets[i].step();
		}
	}
};

module.exports = drawBE;