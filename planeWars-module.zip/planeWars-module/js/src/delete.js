var canDelete = function( hero ) {
	for( var i=0; i<app.enemies.length; i++ ) {
		if( app.enemies[i].outOfBounds() || app.enemies[i].canDelete ) {
			app.enemies.splice( i, 1 );
		}
	}

	for( var i=0; i<app.bullets.length; i++ ) {
		if( app.bullets[i].outOfBounds() || app.bullets[i].canDelete ) {
			app.bullets.splice( i, 1 );
		}
	}

	if( app.hero.canDelete ) {
		app.hero.life--;
		app.hero.born();

		if( app.hero.life === 0 ) {
			app.state = app.GAMEOVER;
		}
	}
};

module.exports = canDelete;