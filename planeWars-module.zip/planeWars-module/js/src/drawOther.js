var drawOther = {
	drawOver: function() {
		var width = Math.ceil( app.ctx.measureText('Game Over').width );
		var x = ( app.canW - width ) / 2 + 20;
		var y = app.canH / 2;

		app.ctx.save();

		app.ctx.font = 'bold 48px Verdana';
		app.ctx.textAlign = 'center';
		app.ctx.shadowBlur = 10;
		app.ctx.shadowColor = '#ccc';

		app.ctx.fillStyle = '#000';
		app.ctx.fillText( 'Game Over', x, y );

		app.ctx.restore();
	},

	drawScore: function() {
		var x = 80;
		var y = 38;

		app.ctx.save();

		app.ctx.font = 'bold 32px Verdana';

		app.ctx.fillStyle = '#000';
		app.ctx.fillText( app.SCORE, x, y );

		app.ctx.restore();
	},

	drawLife: function() {
		var num = app.hero.life;
		var x = app.canW - 125;
		var y = 38;

		app.ctx.save();

		app.ctx.font = 'bold 32px Verdana';

		app.ctx.fillStyle = '#000';
		app.ctx.fillText( 'Life: ' + num, x, y );

		app.ctx.restore();
	},

	drawPause: function() {
		var width = Math.ceil( app.ctx.measureText('Pause').width );
		var x = (app.canW - width) / 2 + 15;
		var y = app.canH / 2;

		app.ctx.save();

		app.ctx.font = 'bold 48px Verdana';
		app.ctx.textAlign = 'center';
		app.ctx.shadowBlur = 10;
		app.ctx.shadowColor = '#ccc';

		app.ctx.fillStyle = '#000';
		app.ctx.fillText( 'Pause', x, y );

		app.ctx.restore();
	},

	drawEntry: function() {
		var entryImg = new Image();
		entryImg.src = 'img/shoot_copyright.png';

		entryImg.onload = function() {
			var width = entryImg.width;
			var height = entryImg.height;
			var x = ( app.canW - width ) / 2;
			var y = ( app.canH - height ) / 2;

			app.ctx.drawImage( entryImg, x, y );
		};
	}
};

module.exports = drawOther;