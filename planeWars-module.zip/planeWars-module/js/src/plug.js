var reqAnimFrame = (function() {
	return window.requestAnimFrame || window.webkitrequestAnimationFrame ||
		   window.mozRequestAnimationFrame || window.oRequestAnimationFrame ||
		   window.msRequestAnimationFrame ||
		   function( callback, element ) {
		   		return window.setTimeout( callback, 1000/60 );
		   };
})();

module.exports = reqAnimFrame;