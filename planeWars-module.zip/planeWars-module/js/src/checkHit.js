var checkHit = function() {
	for( var i=0; i<app.enemies.length; i++ ) {
		if( app.enemies[i].blowDown || app.enemies[i].canDelete ) {
			continue;
		}

		if( app.enemies[i].hit( app.hero ) ) {
			app.enemies[i].bang();
			app.hero.bang();
		}

		if( app.enemies[i].blowDown || app.enemies[i].canDelete ) {
			continue;
		}

		for( var j=0; j<app.bullets.length; j++ ) {
			if( app.enemies[i].hit( app.bullets[j] ) ) {
				app.enemies[i].bang();
				app.bullets[j].canDelete = true;
			}
		}
	}
};

module.exports = checkHit;