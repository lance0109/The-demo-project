var bg = {
	init: function() {
		this.bgImg = new Image();
		this.bgImg.src = 'img/background.png';

		this.x1 = 0;
		this.x2 = 0;
		this.y1 = 0;
		this.y2 = -app.canH;
	},

	step: function() {
		this.y1++;
		this.y2++;

		if( this.y1 >= app.canH ) {
			this.y1 = -app.canH;
		}

		if( this.y2 >= app.canH ) {
			this.y2 = -app.canH;
		}
	},

	draw: function(){
		app.ctx.drawImage( this.bgImg, this.x1, this.y1, app.canW, app.canH );
		app.ctx.drawImage( this.bgImg, this.x2, this.y2, app.canW, app.canH );
	}
};

module.exports = bg;