var hero = {
	init: function() {
		this.heroImg = [];
		for( var i=0; i<6; i++ ) {
			this.heroImg[i] = new Image();
			if( i < 2 ) {
				this.heroImg[i].src = 'img/hero' + ( i + 1 ) + '.png';
			} else {
				this.heroImg[i].src = 'img/hero_blowup_n' + ( i - 1 ) + '.png';
			}
		}

		this.width = 102;
		this.height = 126;

		this.spd = 20;
		this.life = 3;
		this.picIndex = 0;
		this.lastTime = 0;
		this.shootLastTime = 0;
		this.shootInterval = 250;

		this.blowDown = false;
		this.canDelete = false;
	},

	step: function() {
		var curTime = Date.now();

		if( curTime - this.lastTime > this.spd ) {
			if( this.blowDown ) {
				this.pic = this.heroImg[this.picIndex];
				this.picIndex++;
				if( this.picIndex >= 6 ) {
					this.canDelete = true;
				}
			} else {
				this.pic = this.heroImg[ this.picIndex % 2 ];
				this.picIndex++;
			}

			this.lastTime = curTime;
		}
	},

	draw: function() {
		app.ctx.drawImage( this.pic, this.x, this.y );
	},

	shoot: function() {
		var curTime = Date.now();

		if( curTime - this.shootLastTime >= this.shootInterval ) {
			app.bullets.push( new app.Bullet() );
			this.shootLastTime = curTime;
		}
	},

	bang: function() {
		this.blowDown = true;
		this.picIndex = 2;
	},

	born: function() {
		this.blowDown = false;
		this.canDelete = false;
		this.draw();
	}
};

module.exports = hero;